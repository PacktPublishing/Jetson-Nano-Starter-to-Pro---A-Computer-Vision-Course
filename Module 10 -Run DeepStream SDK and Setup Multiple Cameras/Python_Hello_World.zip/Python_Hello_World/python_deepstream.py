import queue
import sys

import gi # provides Python bindings for GStreamer
gi.require_version('Gst', '1.0')

from gi.repository import GObject, Gst
from gi.repository import GLib

from nvidia_source_functions import create_source_bin

from ctypes import *

import math

import pyds

OUTPUT_WIDTH = 1280
OUTPUT_HEIGHT = 720

STREAM_0 = 'rtsp://192.168.0.178:5540/ch0'
STREAM_1 = 'rtsp://192.168.0.102:5540/ch0'

def main(args):
    number_sources = 2

    GObject.threads_init()
    Gst.init(None)

    pipeline = Gst.Pipeline()

    streammux = Gst.ElementFactory.make("nvstreammux", "Stream-muxer")

    pipeline.add(streammux)

    # add first stream
    source_bin = create_source_bin(0, STREAM_0)
    pipeline.add(source_bin)
    padname = "sink_0"
    sinkpad = streammux.get_request_pad(padname)
    srcpad=source_bin.get_static_pad("src")
    srcpad.link(sinkpad)

    # add second stream
    source_bin = create_source_bin(1, STREAM_1)
    pipeline.add(source_bin)
    padname = "sink_1"
    sinkpad = streammux.get_request_pad(padname)
    srcpad=source_bin.get_static_pad("src")
    srcpad.link(sinkpad)

    queue1 = Gst.ElementFactory.make("queue", "queue1")
    queue2 = Gst.ElementFactory.make("queue", "queue2")
    queue3 = Gst.ElementFactory.make("queue", "queue3")
    queue4 = Gst.ElementFactory.make("queue", "queue4")
    queue5 = Gst.ElementFactory.make("queue", "queue5")

    pipeline.add(queue1)
    pipeline.add(queue2)
    pipeline.add(queue3)
    pipeline.add(queue4)
    pipeline.add(queue5)

    pgie = Gst.ElementFactory.make("nvinfer", "primary-inference")

    tiler = Gst.ElementFactory.make("nvmultistreamtiler", "nvtiler")

    nvvidconv = Gst.ElementFactory.make("nvvideoconvert", "convertor")

    nvosd = Gst.ElementFactory.make("nvdsosd", "onscreendisplay")

    nvosd.set_property('process-mode', 0)
    nvosd.set_property('display-text', 1)

    transform = Gst.ElementFactory.make("nvegltransform", "nvegl-transform")
    
    sink = Gst.ElementFactory.make("nveglglessink", "nvvideo-renderer")

    streammux.set_property('live-source', 1)
    streammux.set_property('width', 1920)
    streammux.set_property('height', 1080)
    streammux.set_property('batch-size', number_sources)
    streammux.set_property('batched-push-timeout', 4000000)

    pgie.set_property('config-file-path', 'config_infer_primary.txt')

    tiler_rows = 1 #int(math.sqrt(number_sources))
    tiler_columns = 2 #int(math.ceil((1.0*number_sources)/tiler_rows))

    tiler.set_property("rows", tiler_rows)
    tiler.set_property("columns", tiler_columns)
    tiler.set_property("width", OUTPUT_WIDTH)
    tiler.set_property("height", OUTPUT_HEIGHT)

    sink.set_property("qos", 0)

    pipeline.add(pgie)
    pipeline.add(tiler)
    pipeline.add(nvvidconv)
    pipeline.add(nvosd)
    pipeline.add(transform)
    pipeline.add(sink)

    streammux.link(queue1)
    queue1.link(pgie)
    pgie.link(queue2)
    queue2.link(tiler)
    tiler.link(queue3)
    queue3.link(nvvidconv)
    nvvidconv.link(queue4)
    queue4.link(nvosd)
    nvosd.link(queue5)
    queue5.link(transform)
    transform.link(sink)

    loop = GObject.MainLoop()

    pipeline.set_state(Gst.State.PLAYING)

    try:
        loop.run()
    except:
        pass

    pipeline.set_state(Gst.State.NULL)

if __name__ == '__main__':
    sys.exit(main(sys.argv))
