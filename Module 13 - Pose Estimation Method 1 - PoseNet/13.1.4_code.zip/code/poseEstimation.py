import mediapipe as mp
import time
import cv2

class PoseEstimation():
	def __init__(self):
		self.mp_pose = mp.solutions.pose
		self.mp_drawing = mp.solutions.drawing_utils
		self.pose = self.mp_pose.Pose(min_detection_confidence = 0.2, min_tracking_confidence = 0.2)
		self.cap = cv2.VideoCapture(0)
		self.pTime = 0
		self.org = (00, 40)
		self.font = cv2.FONT_HERSHEY_SIMPLEX
		self.font_scale = 1
		self.color = (0, 255, 0)
		self.thickness = 2

	def run(self):
		while self.cap.isOpened():
			ret, frame = self.cap.read()
			if not ret:
				break

			try:
				frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
				result = self.pose.process(frame_rgb)

				if result.pose_landmarks:
					self.mp_drawing.draw_landmarks(frame, result.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)
			except:
				frame = frame

			cTime = time.time()
			fps = int(1 / (cTime - self.pTime))
			fps_string = str(str(fps) + " FPS")
			self.pTime = cTime

			frame = cv2.putText(frame, fps_string, self.org, self.font, self.font_scale, self.color, self.thickness, self.thickness, False)
			cv2.imshow('MediaPipe Pose', frame)

			if cv2.waitKey(1) & 0xFF == ord('q'):
				break

		self.cap.release()
		cv2.destroyAllWindows()

if __name__ == "__main__":
	pose = PoseEstimation()
	pose.run()
