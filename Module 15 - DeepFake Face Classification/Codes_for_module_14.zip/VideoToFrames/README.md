
Python script that splits videos into individual frames using openCV.  

To use this script, type in the path of the video you want to work with and the path where you want the images saved.
