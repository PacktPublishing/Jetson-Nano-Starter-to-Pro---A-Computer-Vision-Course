
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
gauth = GoogleAuth()           
drive = GoogleDrive(gauth)  

file_list = drive.ListFile({'q': "'{}' in parents and trashed=false".format('1EuhAE8pvY0OjUSpNQerE9dWotL0NzT_I')}).GetList()
for file in file_list:
	print('title: %s, id: %s' % (file['title'], file['id']))

for i, file in enumerate(sorted(file_list, key = lambda x: x['title']), start=1):
	print('Downloading {} file from GDrive ({}/{})'.format(file['title'], i, len(file_list)))
	file.GetContentFile(file['title'])